package uk.ac.mmu.advprog.hackathon;
import static spark.Spark.get;
import static spark.Spark.port;

import spark.Request;
import spark.Response;
import spark.Route;

/**
 * Handles the setting up and starting of the web service
 *@author Dagogo Apiafi.
 */
public class TransportWebService {

	/**
	 * Main program entry point, starts the web service
	 * @param args are not used
	 */
	public static void main(String[] args) {		
		port(8088);
		
		/**The test root to make sure thing are working
		*Accessible via http://localhost:8088/test in your browser
		*/
		get("/test", new Route() {
			@Override
			public Object handle(Request request, Response response) throws Exception {
				try (DB db = new DB()) {
					return "Number of Entries: " + db.getNumberOfEntries();
				}
			}			
		});
		
		/**
		 *Count the number of local stops with this request
		 */
		get("/stopcount", new Route() {
			@Override
			public Object handle(Request request, Response response) throws Exception {
				try (DB db = new DB()) {
					String userslocality = request.queryParams("locality");
					
					if (userslocality == null || userslocality.equals("")){
						return "Invalid request";
					};
					
					return "Number of Entries: " + db.getStopCount(userslocality);
				}
			}		
		});
		
		/**
		 *Give the information of the stop requested by the user
		 */
		get("/stops", new Route() {
			@Override
			public Object handle(Request request, Response response) throws Exception {
				try (DB db = new DB()) {
					String userslocality = request.queryParams("locality");
					String userStopType = request.queryParams("type");
					
					if (userslocality == null || userslocality.equals("")){
						return "Invalid request";
					};
					
					return "The details of your stops are: " + db.getStopType(userslocality, userStopType);
				}
			}		
		});
		
		get("/nearest", new Route() {
			@Override
			public Object handle(Request request, Response response) throws Exception {
				try (DB db = new DB()) {
					String userslocality = request.queryParams("locality");
					String userStopType = request.queryParams("type");
					
					if (userslocality == null || userslocality.equals("")){
						return "Invalid request";
					};
					
					return "The details of your stops are: " + db.getStopType(userslocality, userStopType);
				}
			}		
		});
		
		
		/**
		 *Let us know that the server is running
		 */
		System.out.println("Server up! Don't forget to kill the program when done!");
	}

}
