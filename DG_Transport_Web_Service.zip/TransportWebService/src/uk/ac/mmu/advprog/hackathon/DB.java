package uk.ac.mmu.advprog.hackathon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Handles  the database access from within your web service
 * @author Dagogo Apiafi.
 */
public class DB implements AutoCloseable {

	/**
	 *  allows us to easily change the database used
	 */
	private static final String JDBC_CONNECTION_STRING = "jdbc:sqlite:./data/NaPTAN.db";

	
	/**
	 *  allows us to re-use the connection between queries if desired
	 */
	private Connection connection = null;
	

	/**
	 * Creates an instance of the DB object and connects to the database
	 */
	public DB() {
		try {
			connection = DriverManager.getConnection(JDBC_CONNECTION_STRING);
		} catch (SQLException sqle) {
			error(sqle);
		}
	}

	/**
	 * Returns the number of entries in the database, by counting rows
	 * 
	 * @return The number of entries in the database, or -1 if empty
	 */
	public int getNumberOfEntries() {
		int result = -1;
		try {
			Statement s = connection.createStatement();
			ResultSet results = s.executeQuery("SELECT COUNT(*) AS count FROM Stops");
			while (results.next()) { // will only execute once, because SELECT COUNT(*) returns just 1 number
				result = results.getInt(results.findColumn("count"));
			}
			
		} catch (SQLException sqle) {
			error(sqle);

		}
		return result;
	}

	/**
	 *  collect the locality and give me the number of the stops
	 * @param userLocalityName collects the name of the locality
	 * @return returns the number of the localities collected
	 */
	public int getStopCount(String userLocalityName) {
		int result = 0;
		try {
			PreparedStatement s = connection.prepareStatement("SELECT COUNT (*) AS Number FROM Stops WHERE LocalityName = ?;");
			s.setString(1, userLocalityName);
			ResultSet stopC = s.executeQuery();
			

			while (stopC.next()) {
				result = stopC.getInt(stopC.findColumn("Number"));
				System.out.println("There are: " + stopC.getInt("Number") + " stops in your locality");

			}
		} catch (SQLException sqle) {
			error(sqle);

		}
		return result;
	}
	/**
	 * 
	 * @param locality collects the name of the locality
	 * @param stopType collects the name of the stop type e.g. Bus, MTR(metro)
	 * @return returns the result of the entire array
	 */
	public JSONArray getStopType(String locality, String stopType) {
		JSONArray result = new JSONArray();
		try {
			PreparedStatement s = connection.prepareStatement("SELECT * FROM Stops WHERE LocalityName = ? AND StopType =?;");
			s.setString(1, locality);
			s.setString(2, stopType);
			ResultSet stopT = s.executeQuery();

			while (stopT.next()) {
				JSONObject outerObject = new JSONObject();
				JSONObject innerObject = new JSONObject();
				
				String name = "";
				String localityDB = "";
				String indicator = "";
				String bearing = "";
				String street = "";
				String landmark = "";
				String STtype = "";
				
				
				name = stopT.getString(stopT.findColumn("CommonName"));
				if (name == null) {
					name = "";
				}
				
				localityDB = stopT.getString(stopT.findColumn("LocalityName"));
				if (localityDB == null) {
					localityDB = "";
				}
				
				indicator = stopT.getString(stopT.findColumn("Indicator"));
				if (indicator == null) {
					indicator = "";
				}
				
				bearing = stopT.getString(stopT.findColumn("Bearing"));
				if (bearing == null) {
					bearing = "";
				}
				
				street = stopT.getString(stopT.findColumn("Street"));
				if (street == null) {
					street = "";
				}
				
				landmark = stopT.getString(stopT.findColumn("Landmark"));
				if (landmark == null) {
					landmark = "";
				}
				
				STtype = stopT.getString(stopT.findColumn("StopType"));
				if (STtype == null) {
					STtype = "";
				}
				
				
				
				outerObject.put("name", name);
				outerObject.put("locality", localityDB);
				outerObject.put("location", innerObject);
				innerObject.put("Indicator", indicator);
				innerObject.put("Bearing", bearing);
				innerObject.put("Street", street);
				innerObject.put("Landmark", landmark);
				innerObject.put("StopType", STtype);
				
				
				
				
				result.put(outerObject);
				
			}
			
			
		} catch (SQLException sqle) {
			error(sqle);

		}
		return result;
	}
	
	/**
	 * 
	 * @param THElatitude collects the latitude of the chosen coordinates
	 * @param THElongitude collects the longitude of the chosen coordinates
	 * @param THEtype collects the type of public transport that is searched for
	 * @return
	 */
	public int getNearestRoute(String THElatitude, String THElongitude, String THEtype) {
		int result = 0;
		try {
			PreparedStatement s = connection.prepareStatement("SELECT * FROM Stops WHERE StopType = ? AND ? IS NOT NULL AND ? IS NOT NULL ORDER BY "
					+ "((53.472 - Latitude)*(53.472-Latitude)) + (0.595 * ((-2.244 - Longitude) * (-2.244 - Longitude))) ASC LIMIT 5;");
			
			s.setString(1, THElatitude);
			s.setString(1, THElongitude);
			s.setString(1, THEtype);
			ResultSet stopCoords = s.executeQuery(); 
		
	} catch (SQLException sqle) {
		error(sqle);

	}
	return result;
	}

	/**
	 * Closes the connection to the database, required by AutoCloseable interface.
	 */
	@Override
	public void close() {
		try {
			if (!connection.isClosed()) {
				connection.close();
			}
		} catch (SQLException sqle) {
			error(sqle);
		}
	}

	/**
	 * Prints out the details of the SQL error that has occurred, and exits the
	 * programme
	 * 
	 * @param sqle Exception representing the error that occurred
	 */
	private void error(SQLException sqle) {
		System.err.println("Problem Opening Database! " + sqle.getClass().getName());
		sqle.printStackTrace();
		System.exit(1);
	}
}
